(Post this ONLY after you have actually submitted. Edit brackets.)

Took part in the NASA Space Apps Challenge 2026 🚀

For "The Next Frontier" I built TransitNet: a 1D CNN that reads NASA Kepler light curves and separates real exoplanet transits from false positives like eclipsing binaries, with Grad-CAM to show what the model looked at.

Same idea Google researchers used to find Kepler-90i. Learned a lot about light-curve folding, class imbalance and explainability.

Code: github.com/BhavishyasriMatangi-rgb/<repo>
#NASASpaceApps #Exoplanets #DeepLearning #MachineLearning #Kepler
