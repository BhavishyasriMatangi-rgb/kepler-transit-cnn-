# Space Apps form text (edit challenge name to match what you select)

**Project title:** TransitNet: Explainable 1D-CNN Vetting of Kepler Exoplanet Transits

**Summary (short):** An explainable deep-learning tool that reads NASA Kepler light curves and tells real exoplanet transits apart from look-alike false positives such as eclipsing binaries.

**How it works:** We phase-fold each light curve and build a global view (full orbit) and a local view (zoom on the dip). A two-branch 1D CNN classifies planet vs false positive. Grad-CAM highlights the part of the curve that drove each decision, and a BLS-search helper lets anyone vet a star by name.

**Impact:** Kepler produced thousands of candidate signals; manual vetting is slow. Automated, explainable vetting speeds up discovery and builds trust in the model.

**NASA data used:** Kepler light curves (MAST), NASA Exoplanet Archive KOI cumulative table.

**Tools:** Python, PyTorch, lightkurve, scikit-learn, matplotlib.

**Link:** https://github.com/BhavishyasriMatangi-rgb/<repo-name>

**Use of AI:** AI assistance (Claude) was used to help write code; the team reviewed and ran it. (Declare this honestly in the form's AI-usage section.)
